package com.sravs.myapplication.util

object Constants {
    const val BASE_URL="https://jsonplaceholder.typicode.com"
}