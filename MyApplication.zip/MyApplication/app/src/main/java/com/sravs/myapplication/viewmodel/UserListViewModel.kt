package com.sravs.myapplication.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sravs.myapplication.network.UserRepository
import com.sravs.myapplication.model.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserListViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> get() = _users

    init {
        fetchUsersList()
    }

    fun fetchUsersList() {
        viewModelScope.launch {
            try {
                val response = userRepository.getUsers()
                _users.value = response
            } catch (e: Exception) {
                Log.e("UserListViewModel:", e.toString())
            }
        }
    }
}