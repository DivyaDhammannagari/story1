package com.sravs.myapplication.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sravs.myapplication.R
import com.sravs.myapplication.viewmodel.UserListViewModel
import com.sravs.myapplication.model.User

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserListScreen() {
    val viewModel: UserListViewModel = hiltViewModel()
    val users by viewModel.users.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "User List") },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF8F1FFF), // Set the background color here
                    titleContentColor = Color.White // Set the title text color here
                )
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                LazyColumn {
                    items(users) { user ->
                        UserItem(user = user)
                    }
                }
            }
        }
    )

}

@Composable
fun UserItem(user: User) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Image on the left
        Image(
            painter = painterResource(id = R.drawable.ic_list),
            contentDescription = null,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Text(
                text = "ID: ${user.id}", color = Color.Blue,
                fontSize = 20.sp
            )
            Text(text = "Name: ${user.title}")
            Text(text = "status: ${user.completed}")
        }
    }
}