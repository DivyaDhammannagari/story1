package com.sravs.myapplication.network

import com.sravs.myapplication.model.User
import retrofit2.http.GET

interface ApiNetworkService {
    @GET("/todos")
    suspend fun getUserList():List<User>
}