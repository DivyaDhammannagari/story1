package com.sravs.myapplication.network

import com.sravs.myapplication.model.User
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepository @Inject constructor(
    private val apiService: ApiNetworkService
) {
    suspend fun getUsers(): List<User> = apiService.getUserList()
}