package com.sravs.myapplication.model

data class User(
    var userId: Int,
    var id: Int,
    var title: String,
    var completed: Boolean
)