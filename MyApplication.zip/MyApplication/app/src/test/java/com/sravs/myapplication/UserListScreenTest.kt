package com.sravs.myapplication
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.AndroidComposeTestRule
import androidx.compose.material3.Surface
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.sravs.myapplication.model.User
import com.sravs.myapplication.ui.MainActivity
import com.sravs.myapplication.ui.screens.UserListScreen
import com.sravs.myapplication.ui.theme.MyApplicationTheme
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalComposeUiApi::class)
class UserListScreenTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun userListScreen_displaysUsers() {
        // Given
        val testUsers = listOf(
            User(userId = 1, id = 1, title = "Test User 1", completed = true),
            User(userId = 2,id = 2, title = "Test User 2", completed = false)
        )

        // Launch the UserListScreen with a custom ViewModel
        composeTestRule.setContent {
            MyApplicationTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    UserListScreen() // Assuming it uses a mock ViewModel
                }
            }
        }

        // When
        // Set test data in the ViewModel or use Compose Test Rules to mock

        // Then
        composeTestRule.onNodeWithText("ID: 1").assertIsDisplayed()
        composeTestRule.onNodeWithText("Name: Test User 1").assertIsDisplayed()
        composeTestRule.onNodeWithText("status: true").assertIsDisplayed()

        composeTestRule.onNodeWithText("ID: 2").assertIsDisplayed()
        composeTestRule.onNodeWithText("Name: Test User 2").assertIsDisplayed()
        composeTestRule.onNodeWithText("status: false").assertIsDisplayed()
    }
}
